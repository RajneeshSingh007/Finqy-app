import NavigationStore from "./NavigationStore";

const navigationStore = new NavigationStore();

export default {
  navigationStore: navigationStore
};